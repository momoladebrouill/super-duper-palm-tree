#include <stdio.h>

int main(){
   int nb;
   scanf("%i",&nb);
   printf(nb==64741?"Bon festin !":"Allez-vous en !");
}
