#include <stdio.h>
#include "robot.h"
int main()
{
   haut();
   haut();
   haut();
   droite();
   droite();
   bas();
   bas();
   droite();
}
