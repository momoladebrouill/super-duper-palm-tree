#include <stdio.h>

int main(){
   int purse;
   int priceperbook;
   scanf("%i",&purse);
   scanf("%i",&priceperbook);
   printf("%i", (int)purse/priceperbook);
}
